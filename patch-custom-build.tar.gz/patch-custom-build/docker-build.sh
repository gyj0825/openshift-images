docker build -t registry.access.redhat.com/openshift3/patch-custom-docker-builder:v3.2.1.1 .
